"""Turning an admissible target into orders, and orders into fills.

The fill assumption of this layer, stated once here rather than buried in a
loop: **an order is a market order sent just after the opening auction of the
execution session, sized against that auction's price and filled at it, moved
against the trader by the half spread and the slippage.** The engine decides
which session that is; this module only ever sees one instant, the prices
knowable at it, and the book as it stands.

Being worth something and being tradable are two different questions, and this
layer keeps them apart. A position whose opening auction did not print is still
worth something - the book has to be valued for the other orders to be sized
against it - and it still cannot be traded. So every line the target touches
comes with its observation, and only an opening price of the session itself is
ever filled on: a stale one is a price nobody could have got that morning, and
a missing one is no price at all. Valuation may estimate; execution never does.

The sequence, in full:

1. the book is valued at the execution instant - the opening price where one
   printed, the last known price otherwise - and that equity, before any of
   this rebalancing's costs, sizes every line;
2. each line becomes an order, a reject, or nothing (see
   :meth:`ExecutionModel.rebalance`): a purchase is sized at the price it will
   be paid, a target position is rounded down to whole lots, an order worth
   less than the minimum is not sent;
3. the sales are done first, because they pay for the purchases;
4. the purchases are cut to the cash there is, all by the same factor, and
   what was cut is named.

Nothing is ever bought with cash the book does not hold, and nothing is sold
that it does not own.
"""

from __future__ import annotations

import math
from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass, replace
from datetime import date, datetime
from enum import Enum
from typing import Final

from quant_backtester.data.instruments import InstrumentRegistry
from quant_backtester.data.reader import Observation, ObservationStatus
from quant_backtester.execution.costs import CostModel
from quant_backtester.execution.fills import (
    ExecutionReject,
    ExecutionRejectReason,
    Fill,
    OrderStatus,
)
from quant_backtester.execution.orders import Order, Side
from quant_backtester.execution.rounding import LOT_TOLERANCE, is_whole_lots, whole_lots
from quant_backtester.numbers import require_finite_non_negative, require_unit_fraction
from quant_backtester.portfolio.state import PortfolioState, UnvaluablePosition
from quant_backtester.portfolio.targets import WEIGHT_SUM_TOLERANCE


class Sizing(Enum):
    """Which prices and which book an order's quantity is fixed on."""

    AT_AUCTION = "AT_AUCTION"
    """The opening auction's prices and the book valued at them: an allocation
    in notional at a price already known. ``OPEN_AUCTION_NOTIONAL``."""

    AT_DECISION = "AT_DECISION"
    """The decision's closes and the book valued at them: quantities fixed the
    evening before, filled at the open whatever it prints, and cut to the cash
    there is. ``DECISION_CLOSE_QUANTITIES``. What an account placing its
    orders overnight does; the measure of how much the first model idealises
    (audit of archive 9, C04)."""


FILL_MODELS: Final[dict[Sizing, str]] = {
    Sizing.AT_AUCTION: "OPEN_AUCTION_NOTIONAL",
    Sizing.AT_DECISION: "DECISION_CLOSE_QUANTITIES",
}
"""The name each sizing is recorded and reported under."""

FILL_MODEL = "OPEN_AUCTION_NOTIONAL"
"""The name of the one fill model here, recorded with every run.

A decision taken after a close is traded at the next opening auction: the
book is valued at that auction's prices, each order is sized from them, and
filled at them, sales first. It is an allocation in notional at a known price
- a research approximation, and not the same thing as quantities fixed before
the auction, whose cash would have to cover an opening gap (audit, section
5.1). Its name travels with the result so that nobody reads it as the other.
"""


@dataclass(frozen=True, slots=True)
class Execution:
    """What one rebalancing did, and what it could not do.

    Attributes
    ----------
    at : datetime
        The execution instant.
    state : PortfolioState
        The book after the trades.
    equity : float
        What the book was worth at the execution instant, before any of this
        rebalancing's costs: the amount every target weight was a fraction of.
    orders : tuple[Order, ...]
        Every order the target called for, sales first and then purchases,
        each in instrument order - the order they were executed in.
    fills : tuple[Fill, ...]
        What was done, in the same order.
    rejects : tuple[ExecutionReject, ...]
        What was not, or not in full, and why - in instrument order.
    """

    at: datetime
    state: PortfolioState
    equity: float
    orders: tuple[Order, ...] = ()
    fills: tuple[Fill, ...] = ()
    rejects: tuple[ExecutionReject, ...] = ()

    def __post_init__(self) -> None:
        """Freeze what was recorded."""
        require_finite_non_negative(self.equity, "equity")
        object.__setattr__(self, "orders", tuple(self.orders))
        object.__setattr__(self, "fills", tuple(self.fills))
        object.__setattr__(self, "rejects", tuple(self.rejects))

    @property
    def commission(self) -> float:
        """Return the total paid to the broker."""
        return math.fsum(fill.commission for fill in self.fills)

    @property
    def spread_cost(self) -> float:
        """Return the total paid for crossing the spread."""
        return math.fsum(fill.spread_cost for fill in self.fills)

    @property
    def slippage_cost(self) -> float:
        """Return the total lost to the orders' own impact."""
        return math.fsum(fill.slippage_cost for fill in self.fills)

    @property
    def market_cost(self) -> float:
        """Return the total paid to the market, spread and slippage together."""
        return math.fsum(fill.market_cost for fill in self.fills)

    @property
    def total_cost(self) -> float:
        """Return everything this rebalancing cost."""
        return math.fsum(fill.total_cost for fill in self.fills)

    @property
    def traded_value(self) -> float:
        """Return the total value exchanged at the fill price, both directions counted."""
        return math.fsum(fill.traded_value for fill in self.fills)

    @property
    def gross_cash_flow(self) -> float:
        """Return what the same trades did to the cash of a book that pays no costs."""
        return math.fsum(fill.gross_cash_flow for fill in self.fills)

    def status(self, instrument_id: str) -> OrderStatus | None:
        """Return what became of the order in one instrument.

        Parameters
        ----------
        instrument_id : str
            Instrument to look up.

        Returns
        -------
        OrderStatus | None
            ``None`` when no order was built for it - nothing to do, or a
            reject before any order could be sized.
        """
        ordered = [order for order in self.orders if order.instrument_id == instrument_id]
        if not ordered:
            return None
        wanted = math.fsum(order.quantity for order in ordered)
        done = math.fsum(
            fill.quantity for fill in self.fills if fill.instrument_id == instrument_id
        )
        if done == 0.0:
            return OrderStatus.REJECTED
        if done < wanted:
            return OrderStatus.PARTIALLY_FILLED
        return OrderStatus.FILLED


@dataclass(frozen=True, slots=True)
class _Line:
    """An order with what it takes to fill it.

    ``executable`` is the most of the order that may be filled: the order's own
    quantity, or less for a purchase whose cash-share budget pays for less at
    the fill price. The order keeps the quantity asked for, so the record says
    both what was asked and what the budget allowed.
    """

    order: Order
    market_price: float
    step: float | None
    executable: float


@dataclass(frozen=True, slots=True)
class ExecutionModel:
    """Fills a rebalancing at the opening auction, paying the declared costs.

    Attributes
    ----------
    costs : CostModel
        Commission, spread and slippage. Required: a run reports no return
        without a cost model attached, and a default of zero would be one
        attached without anyone having said so.
    minimum_trade_value : float
        Orders worth less than this, at the fill price, are not sent. A
        rebalancing that moves a position by a few currency units pays a
        commission floor to change nothing, and a backtest without this
        threshold spends its return on noise no one would have traded.

    Raises
    ------
    ValueError
        If ``minimum_trade_value`` is not a finite number of zero or more. A
        threshold of ``NaN`` compares false against every order and would
        silently send them all.
    """

    costs: CostModel
    minimum_trade_value: float = 0.0
    sizing: Sizing = Sizing.AT_AUCTION

    def __post_init__(self) -> None:
        """Reject a threshold that is not a value, or a cost model that is not one."""
        if not isinstance(self.costs, CostModel):
            raise ValueError(f"costs must be a CostModel, got {self.costs!r}")
        require_finite_non_negative(self.minimum_trade_value, "minimum_trade_value")

    def definition(self) -> dict[str, object]:
        """Return the model as it is recorded with a run."""
        return {
            "fill_model": FILL_MODELS[self.sizing],
            "fill": "market order at the opening auction, sized at its price",
            "costs": self.costs.definition(),
            "minimum_trade_value": self.minimum_trade_value,
        }

    def rebalance(
        self,
        state: PortfolioState,
        target: Mapping[str, float],
        *,
        at: datetime,
        session: date,
        quotes: Mapping[str, Observation],
        last_known: Mapping[str, float],
        instruments: InstrumentRegistry,
        base_currency: str,
        universe: Collection[str],
        hold: bool = False,
        keep: Collection[str] = (),
        cash_shares: Mapping[str, float] | None = None,
        decision_closes: Mapping[str, float] | None = None,
    ) -> Execution:
        """Trade the book towards the target weights, at one execution instant.

        Parameters
        ----------
        state : PortfolioState
            What is held before the trades.
        target : Mapping[str, float]
            Accepted fraction of equity per instrument. An instrument held and
            absent from it is a target of zero: the position is closed.
        at : datetime
            The execution instant. Every order is submitted and filled at it.
        session : date
            The session whose opening auction the orders are filled at. Only an
            opening price of that session is ever traded on: an observation the
            reader calls current can still be the previous session's, when the
            instant falls before this one's auction has printed.
        quotes : Mapping[str, Observation]
            The opening price knowable at ``at``, with its status, for every
            instrument that is held or targeted.
        last_known : Mapping[str, float]
            The last price the run knew for each held instrument. Used only to
            value a position whose opening price is not usable, so that the
            other orders can be sized - never to fill one.
        instruments : InstrumentRegistry
            Lot sizes, tradability and currencies.
        base_currency : str
            The currency the book is kept in.
        universe : Collection[str]
            The trading universe on the execution session. A purchase outside
            it is refused; a sale never is.
        hold : bool
            Whether the decision was to keep every position as it is. No order
            is built, whatever the target weights and the overnight moves say:
            they only record what the book was worth when it was decided.
        keep : Collection[str]
            Instruments whose positions are left exactly as they are while the
            others are traded: no order, and no reject, is built for them. Their
            value still counts in the equity every other order is sized on.
        cash_shares : Mapping[str, float] | None
            Lines sized on a share of the cash the book holds at ``at``,
            instead of a share of the equity: a basket completed with the cash
            left buys with that cash, whatever the lines already held did
            overnight (decision D12). A share is a budget, commission included
            (decision D21): with 100 of cash, a share of 0.5 and a minimum
            commission of 10, the line buys 40 and pays 10, and 50 is left.
            Taking the commission off the whole cash before the share left 45
            (audit N06). The budget holds at the price actually paid: a
            quantity fixed at the decision's close is cut to what the share
            pays for at the open, costs included, and the cut is recorded as
            ``CASH_SHARE_BUDGET``; a lower open never buys more than was
            decided (audit of archive 10).
        decision_closes : Mapping[str, float] | None
            The closes knowable at the decision, for every instrument held or
            targeted that had one. Required with ``Sizing.AT_DECISION``, which
            fixes each quantity on them and on the book valued at them; the
            order is still filled at the open, and cut to the cash there is.

        Returns
        -------
        Execution
            The book after the trades, the orders, the fills and the rejects.

        Raises
        ------
        ValueError
            If a target weight is not a finite fraction, the weights add up to
            more than the book, or an observation was not yet knowable at
            ``at`` or describes a later session than ``session`` - a price
            from after the instant it is used at is look-ahead, and it is a
            bug rather than a market situation.
        KeyError
            If a held or targeted instrument has no observation, or is not in
            the registry.
        UnvaluablePosition
            If a held position has neither a usable opening price nor a last
            known price, so the book - and every order sized on it - cannot be
            valued.

        Notes
        -----
        How each line is turned into an order, in instrument order:

        - nothing held and nothing wanted: nothing;
        - an instrument that may not be traded at all - not tradable, another
          currency, a position that is not a whole number of lots - is
          rejected and left exactly as it is;
        - without an opening price of ``session`` itself, the line is
          rejected with ``STALE_EXECUTION_PRICE`` - an older open, including
          one the reader still calls current because this auction has not
          printed yet - or ``NO_EXECUTION_PRICE``.
          The rejection says which way and how much when that is knowable - a
          position to close is a sale of all of it - and leaves both unknown
          otherwise, rather than guessing;
        - every order is a positive whole number of lots, rounded down, so
          that as a signed change of the position the trade is truncated
          towards zero (:mod:`quant_backtester.execution.rounding` states the
          rule once);
        - a purchase is sized at the price it will be paid: the whole lots
          between what is held and ``w * equity / fill_price``, so that the
          value spent is at most the value targeted. It is refused outside the
          universe of the execution session;
        - a sale sells the whole lots of the excess over
          ``w * equity / market_price``: it never sells more than the target
          calls for, and a position to close is sold in full;
        - an order worth less than the minimum trade value is rejected with
          ``BELOW_MINIMUM_TRADE``;
        - a target within a lot of what is held is no order at all: at this
          lot size, it has been reached. Rounding the *trade* rather than the
          target is what makes this true. A target recomputed at the open
          from weights taken at the close drifts by a fraction of a share
          every day; rounded as a position, 198.99 shares against 199 held is
          a sale of one, the next day's 199.01 no purchase, and a book asked
          to hold what it holds sells itself away one lot at a time.
        """
        self._require_target(target)
        equity = self._equity(state, quotes, last_known, at, session)
        if hold:
            return Execution(at=at, state=state, equity=equity)
        sells, buys, rejects = self._plan(
            state,
            {name: weight for name, weight in target.items() if name not in keep},
            keep=frozenset(keep),
            cash_shares=cash_shares or {},
            decision_closes=decision_closes,
            equity=equity,
            at=at,
            session=session,
            quotes=quotes,
            instruments=instruments,
            base_currency=base_currency,
            universe=universe,
        )
        fills: list[Fill] = []
        book = state
        for line in sells:
            fill = Fill.of(line.order, line.market_price, self.costs)
            if book.cash + fill.cash_flow < 0.0:
                # A commission floor larger than what the sale brings in, on a
                # book with nothing left in cash to pay the difference.
                rejects.append(
                    ExecutionReject(
                        line.order.instrument_id,
                        ExecutionRejectReason.INSUFFICIENT_CASH,
                        Side.SELL,
                        line.order.quantity,
                    )
                )
                continue
            book = book.sold(fill.instrument_id, fill.quantity, fill.cash_flow, at)
            fills.append(fill)

        scale = self._affordable_scale(buys, book.cash)
        for line in buys:
            quantity = self._scaled(line, scale)
            capped = line.order.quantity - line.executable
            if capped > LOT_TOLERANCE * line.order.quantity:
                rejects.append(
                    ExecutionReject(
                        line.order.instrument_id,
                        ExecutionRejectReason.CASH_SHARE_BUDGET,
                        Side.BUY,
                        capped,
                    )
                )
            cut = line.executable - quantity if quantity > 0.0 else line.executable
            if quantity > 0.0:
                fill = self._fill(line, quantity)
                book = book.bought(fill.instrument_id, fill.quantity, -fill.cash_flow, at)
                fills.append(fill)
            if cut > LOT_TOLERANCE * line.order.quantity:
                rejects.append(
                    ExecutionReject(
                        line.order.instrument_id,
                        ExecutionRejectReason.INSUFFICIENT_CASH,
                        Side.BUY,
                        cut,
                    )
                )
        return Execution(
            at=at,
            state=book,
            equity=equity,
            orders=tuple(line.order for line in (*sells, *buys)),
            fills=tuple(fills),
            rejects=tuple(sorted(rejects, key=lambda reject: reject.instrument_id)),
        )

    def _spendable(self, cash: float) -> float:
        """Return the notional a purchase can be worth and still pay its commission.

        The fill price already carries the spread and the slippage; what is
        left to fit in the cash is the commission, a rate with a floor.
        """
        costs = self.costs
        return max(
            0.0,
            min(cash - costs.minimum_commission, cash / (1.0 + costs.commission_rate)),
        )

    @staticmethod
    def _require_target(target: Mapping[str, float]) -> None:
        """Raise unless the target is a set of long fractions of one book."""
        for instrument_id, weight in target.items():
            require_unit_fraction(weight, f"the target weight of {instrument_id}")
        total = math.fsum(target.values())
        if total > 1.0 + WEIGHT_SUM_TOLERANCE:
            raise ValueError(
                f"the target weights add up to {total}; this book does not borrow the rest"
            )

    @staticmethod
    def _equity(
        state: PortfolioState,
        quotes: Mapping[str, Observation],
        last_known: Mapping[str, float],
        at: datetime,
        session: date,
    ) -> float:
        """Return the book's worth at the execution instant, before any cost.

        Notes
        -----
        A position whose opening price printed is worth that price; one whose
        price did not is worth the last price the run knew. Being untradable
        this morning and being worthless are not the same thing, and sizing
        every other line as though it were would sell half a book because one
        auction was late.
        """
        prices: dict[str, float] = {}
        for instrument_id in state.holdings:
            price = _opening_price(quotes[instrument_id], at, session)
            if price is not None:
                prices[instrument_id] = price
                continue
            carried = last_known.get(instrument_id)
            if carried is None:
                raise UnvaluablePosition(
                    f"{instrument_id} is held and has never had a knowable price; the book "
                    f"cannot be valued at {at.isoformat()}, so no order can be sized"
                )
            prices[instrument_id] = carried
        return state.value_at(prices)

    def _plan(
        self,
        state: PortfolioState,
        target: Mapping[str, float],
        *,
        equity: float,
        at: datetime,
        session: date,
        quotes: Mapping[str, Observation],
        instruments: InstrumentRegistry,
        base_currency: str,
        universe: Collection[str],
        keep: frozenset[str] = frozenset(),
        cash_shares: Mapping[str, float] | None = None,
        decision_closes: Mapping[str, float] | None = None,
    ) -> tuple[list[_Line], list[_Line], list[ExecutionReject]]:
        """Return the sales, the purchases and the rejects the target calls for."""
        shares = cash_shares or {}
        at_decision = self.sizing is Sizing.AT_DECISION
        if at_decision and decision_closes is None:
            raise ValueError("quantities fixed at the decision need the decision's closes")
        closes = decision_closes or {}
        if at_decision:
            # The book as the decision valued it: held lines at their closes.
            equity = state.cash + math.fsum(
                holding.quantity * closes.get(name, 0.0) for name, holding in state.holdings.items()
            )
        sells: list[_Line] = []
        buys: list[_Line] = []
        rejects: list[ExecutionReject] = []
        for instrument_id in sorted((set(target) | set(state.holdings)) - keep):
            weight = target.get(instrument_id, 0.0)
            held = state.quantity(instrument_id)
            if weight == 0.0 and held == 0.0:
                continue
            instrument = instruments.get(instrument_id)
            step = instrument.quantity_step
            side, quantity = _known_order(weight, held)
            refusal: ExecutionRejectReason | None = None
            if not instrument.tradable:
                refusal = ExecutionRejectReason.NON_TRADABLE
            elif instrument.currency != base_currency:
                refusal = ExecutionRejectReason.CURRENCY_MISMATCH
            elif not is_whole_lots(held, step):
                refusal = ExecutionRejectReason.INVALID_QUANTITY
            else:
                quote = quotes[instrument_id]
                price = _opening_price(quote, at, session)
                if price is None:
                    refusal = (
                        ExecutionRejectReason.NO_EXECUTION_PRICE
                        if quote.value is None
                        else ExecutionRejectReason.STALE_EXECUTION_PRICE
                    )
                elif at_decision and instrument_id not in closes:
                    refusal = ExecutionRejectReason.NO_DECISION_PRICE
                else:
                    line, refusal, side, quantity = self._line(
                        instrument_id,
                        price=price,
                        sizing_price=closes[instrument_id] if at_decision else price,
                        value=(
                            self._spendable(state.cash * shares[instrument_id])
                            if instrument_id in shares
                            else equity * weight
                        ),
                        held=held,
                        step=step,
                        at=at,
                        in_universe=instrument_id in universe,
                    )
                    if line is not None and line.order.side is Side.BUY and instrument_id in shares:
                        line, refusal = self._within_budget(
                            line, state.cash * shares[instrument_id]
                        )
                        if refusal is not None:
                            side, quantity = Side.BUY, line.order.quantity
                            line = None
                    if line is not None:
                        (buys if line.order.side is Side.BUY else sells).append(line)
            if refusal is not None:
                rejects.append(ExecutionReject(instrument_id, refusal, side, quantity))
        return sells, buys, rejects

    def _line(
        self,
        instrument_id: str,
        *,
        price: float,
        sizing_price: float,
        value: float,
        held: float,
        step: float | None,
        at: datetime,
        in_universe: bool,
    ) -> tuple[_Line | None, ExecutionRejectReason | None, Side | None, float | None]:
        """Return the order one line needs, or why it gets none.

        Returns
        -------
        tuple[_Line | None, ExecutionRejectReason | None, Side | None, float | None]
            The order to send, or the reason it is refused together with the
            side and the quantity refused. All four are ``None`` when the line
            is already at its target, to within a lot.
        """
        buy = _units_to_buy(value, self.costs.fill_price(Side.BUY, sizing_price), held, step)
        if buy > 0.0:
            if not in_universe:
                return None, ExecutionRejectReason.OUTSIDE_TRADING_UNIVERSE, Side.BUY, buy
            if buy * self.costs.fill_price(Side.BUY, price) < self.minimum_trade_value:
                return None, ExecutionRejectReason.BELOW_MINIMUM_TRADE, Side.BUY, buy
            line = _Line(Order(instrument_id, Side.BUY, buy, at), price, step, buy)
            return line, None, None, None
        sell = _units_to_sell(value, sizing_price, held, step)
        if sell > 0.0:
            if sell * self.costs.fill_price(Side.SELL, price) < self.minimum_trade_value:
                return None, ExecutionRejectReason.BELOW_MINIMUM_TRADE, Side.SELL, sell
            line = _Line(Order(instrument_id, Side.SELL, sell, at), price, step, sell)
            return line, None, None, None
        return None, None, None, None

    def _within_budget(
        self, line: _Line, budget: float
    ) -> tuple[_Line, ExecutionRejectReason | None]:
        """Cap a cash-share purchase at what its budget pays for at the fill price.

        Parameters
        ----------
        line : _Line
            The purchase, sized on the decision's close or the auction's price.
        budget : float
            Its share of the cash held before any trade, costs included.

        Returns
        -------
        tuple[_Line, ExecutionRejectReason | None]
            The line with ``executable`` cut to the whole lots the budget pays
            for at the opening price, commission, spread and slippage included
            - never above the quantity asked for, so a lower open does not buy
            more than was decided - and ``BELOW_MINIMUM_TRADE`` when what is
            left is under the minimum trade value.

        Notes
        -----
        Checked with the fill itself: if rounding leaves the booked debit of
        the capped quantity above the budget, one lot less is taken (audit of
        archive 10).
        """
        price = self.costs.fill_price(Side.BUY, line.market_price)
        affordable = _units_to_buy(self._spendable(budget), price, 0.0, line.step)
        executable = min(line.order.quantity, affordable)
        for _ in range(64):
            if executable <= 0.0 or -self._fill(line, executable).cash_flow <= budget:
                break
            # One lot less, or - without lots - a hair less: the overshoot is
            # the last bit of a division, never a whole unit.
            executable = max(0.0, executable - (line.step or executable * 1e-12))
        if executable * price < self.minimum_trade_value:
            return line, ExecutionRejectReason.BELOW_MINIMUM_TRADE
        return replace(line, executable=executable), None

    def _fill(self, line: _Line, quantity: float) -> Fill:
        """Return the fill of ``quantity`` units of a line's order."""
        order = line.order
        if quantity != order.quantity:
            order = Order(order.instrument_id, order.side, quantity, order.submitted_at)
        return Fill.of(order, line.market_price, self.costs)

    def _scaled(self, line: _Line, scale: float) -> float:
        """Return the units of a purchase sent at ``scale`` of its size, or ``0.0``.

        Notes
        -----
        Rounded down to the lot after scaling, and dropped when what remains
        is worth less than the minimum trade value - an order cut below the
        threshold is exactly the order the threshold exists to stop.
        """
        wanted = line.executable
        if scale >= 1.0:
            return wanted
        if line.step is None:
            quantity = wanted * scale
        else:
            quantity = whole_lots(wanted * scale, line.step) * line.step
        if quantity <= 0.0:
            return 0.0
        price = self.costs.fill_price(Side.BUY, line.market_price)
        if quantity * price < self.minimum_trade_value:
            return 0.0
        return quantity

    def _cash_left(self, buys: Sequence[_Line], cash: float, scale: float) -> float:
        """Return the cash left after buying ``scale`` of every purchase.

        Notes
        -----
        Computed with the very operations the purchases are then booked with,
        in the same order - the fill's value plus its commission, subtracted
        one purchase at a time - so that what is found affordable is what is
        afterwards paid, to the last bit. The same numbers added in another
        order differ by an ulp, and an ulp below zero is a book that borrowed.
        """
        left = cash
        for line in buys:
            quantity = self._scaled(line, scale)
            if quantity > 0.0:
                fill = self._fill(line, quantity)
                left = left - (-fill.cash_flow)
        return left

    def _affordable_scale(self, buys: Sequence[_Line], cash: float) -> float:
        """Return the largest fraction of the purchases the cash can carry.

        Parameters
        ----------
        buys : Sequence[_Line]
            The purchases this rebalancing wants, at full size, in the order
            they will be booked.
        cash : float
            What is left after the sales.

        Returns
        -------
        float
            ``1.0`` when everything fits, and otherwise the largest fraction
            at which every purchase - scaled, then rounded down to its lot -
            still fits. Every order is cut by the same fraction, so the book
            keeps the proportions the strategy asked for: cutting one name to
            the bone to leave another whole would be a decision about the
            strategy, and this layer does not take those.

        Notes
        -----
        Found by bisection rather than by formula. A commission floor does not
        scale with the order it is charged on, and whole lots move in steps, so
        the cash a set of purchases needs is a step function of their size
        with no closed form. It never decreases as the size grows, which is
        all a bisection needs, and sixty halvings take the answer well past
        the precision of the numbers it is made of. Because the rounding is
        inside the search, the cash a rounded-down lot leaves is used by the
        others - in proportion, never by picking a winner.
        """
        if not buys or self._cash_left(buys, cash, 1.0) >= 0.0:
            return 1.0
        low, high = 0.0, 1.0
        for _ in range(60):
            middle = (low + high) / 2.0
            if self._cash_left(buys, cash, middle) >= 0.0:
                low = middle
            else:
                high = middle
        return low


def _known_order(weight: float, held: float) -> tuple[Side | None, float | None]:
    """Return the side and quantity a line needs, when they are knowable without a price.

    A position to close is a sale of all of it, and a position to open is a
    purchase of an unknown size. A position held and still wanted may need
    either, and saying which would take the price that is missing.
    """
    if weight == 0.0:
        return Side.SELL, held
    if held == 0.0:
        return Side.BUY, None
    return None, None


def _units_to_buy(value: float, price: float, held: float, step: float | None) -> float:
    """Return the units to buy so the position reaches ``value`` at ``price``, or ``0.0``."""
    if value == 0.0:
        return 0.0
    if step is None:
        wanted = value / price
        return wanted - held if wanted - held > LOT_TOLERANCE * wanted else 0.0
    lots = whole_lots(value / price, step) - round(held / step)
    return lots * step if lots > 0 else 0.0


def _units_to_sell(value: float, price: float, held: float, step: float | None) -> float:
    """Return the units to sell to bring the position down to ``value``, or ``0.0``.

    The excess over the target is sold in whole lots, rounded down: never more
    than the target calls for, and nothing at all when the excess is less than
    a lot. A target of nothing sells the whole position, however many lots
    that is, so that a position is always closable in full.
    """
    if held == 0.0:
        return 0.0
    if value == 0.0:
        return held
    excess = held - value / price
    if step is None:
        return excess if excess > LOT_TOLERANCE * held else 0.0
    if excess <= 0.0:
        return 0.0
    lots = whole_lots(excess, step)
    return min(lots * step, held) if lots > 0 else 0.0


def _opening_price(quote: Observation, at: datetime, session: date) -> float | None:
    """Return the opening price of ``session`` an observation carries, or ``None``.

    Parameters
    ----------
    quote : Observation
        The latest opening price the reader had at ``at``.
    at : datetime
        The execution instant.
    session : date
        The session the order is filled in.

    Returns
    -------
    float | None
        The price, when the observation is current *and* describes that very
        session. ``None`` otherwise: a stale open, a missing one, or an open
        the reader calls current because the instant falls before this
        session's auction - the previous session's open, still the latest
        one there is, and still not a price anyone could trade at today.

    Raises
    ------
    ValueError
        If the observation became knowable after ``at``, or describes a
        session after ``session``. Either is a price from the future, which
        is a bug in whoever read it, not a market situation.
    """
    if quote.available_at is not None and quote.available_at > at:
        raise ValueError(
            f"the price of {quote.instrument_id} became knowable at "
            f"{quote.available_at.isoformat()}, after the execution at {at.isoformat()}; "
            "filling on it would be look-ahead"
        )
    if quote.observation_date is not None and quote.observation_date > session:
        raise ValueError(
            f"the price of {quote.instrument_id} describes {quote.observation_date}, after "
            f"the session {session} it is used in; filling on it would be look-ahead"
        )
    if quote.status is not ObservationStatus.OK or quote.value is None:
        return None
    if quote.observation_date != session:
        return None
    return quote.value
